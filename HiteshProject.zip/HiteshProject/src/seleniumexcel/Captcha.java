package seleniumexcel;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;



public class Captcha {
	
	@Test	
	public void addSheetAndColumns() {
		
		// Add Sheet and some starting Columns
		Xls_Reader reader2 = new Xls_Reader("C:/Users/Akshay.Takrani/Desktop/Akshay Personal/Selenium/Hitesh_Excel.xlsx");
		reader2.addSheet("CompaniesData");
		reader2.addColumn("CompaniesData", "CIN");
		reader2.addColumn("CompaniesData", "Company Name");
		
		for(int i=1;i<=10;i++) {
			reader2.addColumn("CompaniesData", "DIN " + i);
			reader2.addColumn("CompaniesData", "Director Name " + i);
			reader2.addColumn("CompaniesData", "Begin Date " + i);
			reader2.addColumn("CompaniesData", "End Date " + i);
			reader2.addColumn("CompaniesData", "Surrendered DIN " + i);
		}
	}

	int row = 1;
	@Test(dataProvider="getData")
	public void run(String CIN) throws IOException, TesseractException, InterruptedException {
		row++;
		//ChromeOptions options = new ChromeOptions();
		//options.addArguments("headless");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.mca.gov.in/mcafoportal/viewCompanyMasterData.do");
		driver.manage().window().maximize();
		//driver.manage().window().setSize(new Dimension(1440,900));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		// Give the path from where you want to read and store data
		Xls_Reader reader = new Xls_Reader("C:/Users/Akshay.Takrani/Desktop/Akshay Personal/Selenium/Hitesh_Excel.xlsx");
		File src = driver.findElement(By.id("captcha")).getScreenshotAs(OutputType.FILE);
		String path = System.getProperty("user.dir")+"/target/captcha.png";
		FileHandler.copy(src, new File(path));
		ITesseract image = new Tesseract();
		String imageText = image.doOCR(new File(path));
		//System.out.println(imageText);
		driver.findElement(By.name("companyID")).sendKeys(CIN);
		driver.findElement(By.id("userEnteredCaptcha")).sendKeys(imageText);
		//driver.findElement(By.id("companyLLPMasterData_0")).click();
		Thread.sleep(1000);
		List<WebElement> list = driver.findElements(By.id("msgboxclose"));
		
		while(!(list.isEmpty())) {
			//System.out.println(list.get(0));
			driver.findElement(By.id("msgboxclose")).click();
			Thread.sleep(1000);
			src = driver.findElement(By.id("captcha")).getScreenshotAs(OutputType.FILE);
			FileHandler.copy(src, new File(path));
			imageText = image.doOCR(new File(path));
			//System.out.println(imageText);
			driver.findElement(By.name("companyID")).sendKeys(CIN);
			driver.findElement(By.id("userEnteredCaptcha")).sendKeys(imageText);
			//driver.findElement(By.id("companyLLPMasterData_0")).click();
			Thread.sleep(1000);
			list = driver.findElements(By.id("msgboxclose"));
			//System.out.println(list.get(0));
		}
		
		//System.out.println("Found data table");
		//driver.quit();
		
		//table[@id='resultTab1']/tbody/tr[1]/td[2]
		
	
		String beforexpath_companyInfo = "//table[@id='resultTab1']/tbody/tr[";
		String afterxpath_companyInfo = "]/td[1]";
		
		String beforexpath_companydata = "//table[@id='resultTab1']/tbody/tr[";
		String afterxpath_companydata = "]/td[2]";
		
		reader.setCellData("CompaniesData", "CIN", row, CIN);
		reader.setCellData("CompaniesData", "Company Name", row, driver.findElement(By.xpath("//table[@id='resultTab1']/tbody/tr[2]/td[2]")).getText());
		
		// COMPANY/LLP MASTER DATA TABLE
		
		ArrayList<String> list1 = new ArrayList<String>();
		list1 = reader.getFirstRowData("CompaniesData");	// get all the column names in a list - list1
		for(int i=3;i<=20;i++) {	// start from 3rd row because we have already collected 1st and 2nd row data in line 101 and 102.
		String actualXpath_companyInfo = beforexpath_companyInfo + i + afterxpath_companyInfo;
		String companyInfo = driver.findElement(By.xpath(actualXpath_companyInfo)).getText();
		//System.out.println(companyInfo);
		if(!list1.contains(companyInfo)) {		// check if list1 contains the column name
		reader.addColumn("CompaniesData", companyInfo);		// if it does not contain, then add the column in the sheet
		}
		String actualXpath_companydata = beforexpath_companydata + i + afterxpath_companydata;
		String companydata = driver.findElement(By.xpath(actualXpath_companydata)).getText();
		//System.out.println(companydata);
		reader.setCellData("CompaniesData", companyInfo, row, companydata);

		}
		
		// CHARGES TABLE
		
				List<WebElement> list2 = driver.findElements(By.xpath("//table[@id='resultTab5']/tbody/tr"));
				int chargesTableSize = list2.size() - 1;
				if(driver.findElement(By.xpath("//table[@id='resultTab5']/tbody/tr[2]/td")).getText().contains("No Charges Exists for Company/LLP")) {
					//System.out.println("charges table has no data");
				}
				else
				{
					//System.out.println("collect charges table data");
					for(int i=1;i<=chargesTableSize;i++) {
						if(!list1.contains("Charge Id "+i)) {
							reader.addColumn("CompaniesData", "Charge Id "+i);
							reader.addColumn("CompaniesData", "Assets Under Charge "+i);
							reader.addColumn("CompaniesData", "Charge Amount "+i);
							reader.addColumn("CompaniesData", "Date of Creation "+i);
							reader.addColumn("CompaniesData", "Date of Modification "+i);
							reader.addColumn("CompaniesData", "Status "+i);
						}
						// write data from charges table
						String chargeId = driver.findElement(By.xpath("//table[@id='resultTab5']/tbody/tr["+(i+1)+"]/td[1]")).getText();
						String assetsUnderCharge = driver.findElement(By.xpath("//table[@id='resultTab5']/tbody/tr["+(i+1)+"]/td[2]")).getText();
						String chargeAmount = driver.findElement(By.xpath("//table[@id='resultTab5']/tbody/tr["+(i+1)+"]/td[3]")).getText();
						String dateOfCreation = driver.findElement(By.xpath("//table[@id='resultTab5']/tbody/tr["+(i+1)+"]/td[4]")).getText();
						String dateOfModification = driver.findElement(By.xpath("//table[@id='resultTab5']/tbody/tr["+(i+1)+"]/td[5]")).getText();
						String status = driver.findElement(By.xpath("//table[@id='resultTab5']/tbody/tr["+(i+1)+"]/td[6]")).getText();
						
						reader.setCellData("CompaniesData", "Charge Id "+i, row, chargeId);
						reader.setCellData("CompaniesData", "Assets Under Charge "+i, row, assetsUnderCharge);
						reader.setCellData("CompaniesData", "Charge Amount "+i, row, chargeAmount);
						reader.setCellData("CompaniesData", "Date of Creation "+i, row, dateOfCreation);
						reader.setCellData("CompaniesData", "Date of Modification "+i, row, dateOfModification);
						reader.setCellData("CompaniesData", "Status "+i, row, status);
					}
				}
		
		// DIRECTORS TABLE
		
		int noOfDirectors = driver.findElements(By.xpath("//table[@id='resultTab6']/tbody/tr")).size();
		//JavascriptExecutor js = (JavascriptExecutor) driver;
		
		for(int i=2;i<=noOfDirectors;i++) {
			//js.executeScript("window.scrollBy(0,500)", "");
			
			WebElement DIN_xpath = driver.findElement(By.xpath("//table[@id='resultTab6']/tbody/tr["+i+"]/td/a"));
			String DIN = driver.findElement(By.xpath("//table[@id='resultTab6']/tbody/tr["+i+"]/td/a")).getText();
			String DirectorName = driver.findElement(By.xpath("//table[@id='resultTab6']/tbody/tr["+i+"]/td[2]")).getText();
			String BeginDate = driver.findElement(By.xpath("//table[@id='resultTab6']/tbody/tr["+i+"]/td[3]")).getText();
			String EndDate = driver.findElement(By.xpath("//table[@id='resultTab6']/tbody/tr["+i+"]/td[4]")).getText();
			String SurrenderedDIN = driver.findElement(By.xpath("//table[@id='resultTab6']/tbody/tr["+i+"]/td[5]")).getText();
			
			reader.setCellData("CompaniesData", "DIN "+(i-1), row, DIN);
			reader.setCellData("CompaniesData", "Director Name "+(i-1), row, DirectorName);
			reader.setCellData("CompaniesData", "Begin Date "+(i-1), row, BeginDate);
			reader.setCellData("CompaniesData", "End Date "+(i-1), row, EndDate);
			reader.setCellData("CompaniesData", "Surrendered DIN "+(i-1), row, SurrenderedDIN);
			
			  DIN_xpath.click();	// click on DIN link
			  Set<String> windows = driver.getWindowHandles(); // {parentId, childId}
			  Iterator<String> it = windows.iterator(); 
			  String parentId = it.next(); 
			  String childId = it.next(); 
			  driver.switchTo().window(childId);
			  
			  // after switching to Director DIN window
			  int tablesize = driver.findElements(By.xpath("//div[@id='dirMasterData']/table[2]/tbody/tr")).size();
			  if(tablesize > 2) {
				  // collect data
				  for(int j=1;j<=tablesize-2;j++) {
					  if(!list1.contains("CIN "+j)) {
						  reader.addColumn("CompaniesData", "Company Director Name "+j);
						  reader.addColumn("CompaniesData", "CIN "+j);
						  reader.addColumn("CompaniesData", "Company Name "+j);
						  reader.addColumn("CompaniesData", "Company Begin Date "+j);
						  reader.addColumn("CompaniesData", "Company End Date "+j);
					  }
					  String companyCIN = driver.findElement(By.xpath("//div[@id='dirMasterData']/table[2]/tbody/tr["+(j+2)+"]/td[1]")).getText();
					  String companyName = driver.findElement(By.xpath("//div[@id='dirMasterData']/table[2]/tbody/tr["+(j+2)+"]/td[2]")).getText();
					  String companyBeginDate = driver.findElement(By.xpath("//div[@id='dirMasterData']/table[2]/tbody/tr["+(j+2)+"]/td[3]")).getText();
					  String companyEndDate = driver.findElement(By.xpath("//div[@id='dirMasterData']/table[2]/tbody/tr["+(j+2)+"]/td[4]")).getText();
					  
					  reader.setCellData("CompaniesData", "Company Director Name "+j, row, DirectorName);
					  reader.setCellData("CompaniesData", "CIN "+j, row, companyCIN);
					  reader.setCellData("CompaniesData", "Company Name "+j, row, companyName);
					  reader.setCellData("CompaniesData", "Company Begin Date "+j, row, companyBeginDate);
					  reader.setCellData("CompaniesData", "Company End Date "+j, row, companyEndDate);
				  }
			  }
			  driver.close();
			  
			  
			  driver.switchTo().window(parentId);
		}
		
		
		
		driver.quit();
	
	}
	
	@DataProvider
	public Object[] getData() {
		
		Xls_Reader reader1 = new Xls_Reader("C:/Users/Akshay.Takrani/Desktop/Akshay Personal/Selenium/Hitesh_Excel.xlsx");
		int rowCount = reader1.getRowCount("Sheet1");
		//System.out.println(rowCount);
		Object[] data = new Object[rowCount-1];
		for(int i=1;i<=rowCount-1;i++) {
			data[i-1] = reader1.getCellData("Sheet1", "CIN", i+1);
		}
		//System.out.println(Arrays.toString(data));
		return data;
		
	}


}
