package seleniumexcel;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Hitesh {

	@Test
	public void addSheetAndColumns() {
		
		Xls_Reader reader2 = new Xls_Reader("C:/Users/Akshay.Takrani/Desktop/Akshay Personal/Selenium/Hitesh_Excel.xlsx");
		reader2.addSheet("CompaniesData");
		reader2.addColumn("CompaniesData", "Company Name");
		for(int i=1;i<=10;i++) {
			reader2.addColumn("CompaniesData", "Director Name" + i);
			reader2.addColumn("CompaniesData", "DIN" + i);
			reader2.addColumn("CompaniesData", "DSC Registerd Or Not" + i);
		}
	}
	
	int row = 1;
	@Test(dataProvider="getData")
	public void run(String companyName) throws IOException {
		row++;
		ChromeOptions options = new ChromeOptions();
		options.addExtensions(new File("C:\\Users\\Akshay.Takrani\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\Extensions\\gighmmpiobklfepjocnamgkkbiglidom\\5.3.2_0.crx"));
		
		//ChromeOptions options = new ChromeOptions();
		//options.addArguments("headless");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Akshay.Takrani\\Desktop\\Akshay Personal\\Selenium\\chromedriver_107\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(options);
		
		driver.manage().window().maximize();
		//driver.manage().window().setSize(new Dimension(1440,900));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
		WebDriverWait w = new WebDriverWait(driver,Duration.ofSeconds(5));
		
		Xls_Reader reader = new Xls_Reader("C:/Users/Akshay.Takrani/Desktop/Akshay Personal/Selenium/Hitesh_Excel.xlsx");
		
		driver.get("https://www.quickcompany.in/company/"+companyName);
		
		
		
		  Set<String> windows = driver.getWindowHandles(); // {parentId, childId}
		  Iterator<String> it = windows.iterator(); String parentId = it.next(); String
		  childId = it.next(); driver.switchTo().window(childId).close();
		  driver.switchTo().window(parentId);
		 
		 
		
		String CIN = driver.findElement(By.xpath("//table[@class='table table-striped']//strong")).getText();
		//System.out.println(CIN);
		
		String CIN_Number = driver.findElement(By.xpath("//table[@class='table table-striped']//a")).getText();
		//System.out.println(CIN_Number);
		
		//table[@class='table table-striped']/tbody/tr[1]/td[1]
		
		int rows = driver.findElements(By.xpath("(//table[@class='table table-striped'])[1]/tbody/tr")).size();
		int col = driver.findElements(By.xpath("//table[@class='table table-striped']/tbody/tr[1]/td")).size();
		
		String beforexpath_companyInfo = "//table[@class='table table-striped']/tbody/tr[";
		String afterxpath_companyInfo = "]/td[1]";
		
		String beforexpath_companydata = "//table[@class='table table-striped']/tbody/tr[";
		String afterxpath_companydata = "]/td[2]";
		
		
		reader.setCellData("CompaniesData", "Company Name", row, companyName);
		
		ArrayList<String> list = new ArrayList<String>();
		list = reader.getFirstRowData("CompaniesData");
		for(int i=1;i<=rows;i++) {
		String actualXpath_companyInfo = beforexpath_companyInfo + i + afterxpath_companyInfo;
		String companyInfo = driver.findElement(By.xpath(actualXpath_companyInfo)).getText();
		//System.out.println(companyInfo);
		if(!list.contains(companyInfo)) {
		reader.addColumn("CompaniesData", companyInfo);
		}
		String actualXpath_companydata = beforexpath_companydata + i + afterxpath_companydata;
		String companydata = driver.findElement(By.xpath(actualXpath_companydata)).getText();
		//System.out.println(companydata);
		reader.setCellData("CompaniesData", companyInfo, row, companydata);

		}
		
		/*
		 * for(int i=1;i<=10;i++) { reader.addColumn("CompaniesData", "Director Name" +
		 * i); reader.addColumn("CompaniesData", "DIN" + i);
		 * reader.addColumn("CompaniesData", "DSC Registerd Or Not" + i); }
		 */
		
		//String director = driver.findElement(By.xpath("//h3[@id='directors']/parent::div/div/div")).getAttribute("data-original-title");
		int noOfDirectors = driver.findElements(By.xpath("//h3[@id='directors']/parent::div/div/div")).size();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		for(int i=1;i<=noOfDirectors;i++) {
			js.executeScript("window.scrollBy(0,2500)", "");
			String directorxpath = "//h3[@id='directors']/parent::div/div/div["+i+"]";
			String directorName = driver.findElement(By.xpath(directorxpath)).getAttribute("data-original-title");
			//System.out.println(directorName);
			driver.findElement(By.xpath(directorxpath+"/a")).click();
			/*if(driver.findElement(By.id("aswift_4")).isDisplayed())
			{
			driver.switchTo().frame(driver.findElement(By.id("aswift_4")));
			driver.switchTo().frame(driver.findElement(By.id("ad_iframe")));
			driver.findElement(By.xpath("//*[@id=\"dismiss-button\"]")).click();
			driver.switchTo().defaultContent();
			}*/
			String DIN = driver.findElement(By.xpath("//table[@class='table table-striped']/tbody/tr[1]/td[1]/strong")).getText();
			String DIN_Number = driver.findElement(By.xpath("//table[@class='table table-striped']/tbody/tr[1]/td[2]/strong")).getText();
			String DSC_Registered = driver.findElement(By.xpath("//table[@class='table table-striped']/tbody/tr[2]/td[1]/strong")).getText();
			String DSC_Registered_Status = driver.findElement(By.xpath("//table[@class='table table-striped']/tbody/tr[2]/td[2]")).getText();
			//System.out.println(DIN + " is " + DIN_Number);
			//System.out.println(DSC_Registered + " " + DSC_Registered_Status);
			driver.get("https://www.quickcompany.in/company/"+companyName);
			//w.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@href,'jivan-samruddhi')]")));
			//driver.findElement(By.xpath("//a[contains(@href,'jivan-samruddhi')]")).click();
			reader.setCellData("CompaniesData", "Director Name"+i, row, directorName);
			reader.setCellData("CompaniesData", "DIN"+i, row, DIN_Number);
			reader.setCellData("CompaniesData", "DSC Registerd Or Not"+i, row, DSC_Registered_Status);
			
		}
		
		
		List<WebElement> list1 = driver.findElements(By.xpath("//h3[@id='charges']"));
		if(!(list1 == null)) {
			int noOfRows = driver.findElements(By.xpath("(//table[@class='table table-striped'])[2]/tbody//tr")).size();
			//driver.findElement(By.xpath("(//table[@class='table table-striped'])[2]/tbody//tr[1]/td[1]/b")).getText();

			for(int i=1;i<=noOfRows;i++) {
				if(!list.contains("Name" + i))
				reader.addColumn("CompaniesData", "Name" + i);
				if(!list.contains("Date" + i))
				reader.addColumn("CompaniesData", "Date" + i);
				if(!list.contains("Status" + i))
				reader.addColumn("CompaniesData", "Status" + i);
				if(!list.contains("Amount" + i))
				reader.addColumn("CompaniesData", "Amount" + i);
				String name = driver.findElement(By.xpath("(//table[@class='table table-striped'])[2]/tbody//tr["+i+"]/td[1]/b")).getText();
				reader.setCellData("CompaniesData", "Name"+i, row, name);
				String date = driver.findElement(By.xpath("(//table[@class='table table-striped'])[2]/tbody//tr["+i+"]/td[2]")).getText();
				reader.setCellData("CompaniesData", "Date"+i, row, date);
				String status = driver.findElement(By.xpath("(//table[@class='table table-striped'])[2]/tbody//tr["+i+"]/td[3]")).getText();
				reader.setCellData("CompaniesData", "Status"+i, row, status);
				String amount = driver.findElement(By.xpath("(//table[@class='table table-striped'])[2]/tbody//tr["+i+"]/td[4]")).getText();
				reader.setCellData("CompaniesData", "Amount"+i, row, amount);
			}
		}
		
		driver.quit();
		
	}
	
	
	
	@DataProvider
	public Object[] getData() {
		
		Xls_Reader reader1 = new Xls_Reader("C:/Users/Akshay.Takrani/Desktop/Akshay Personal/Selenium/Hitesh_Excel.xlsx");
		int rowCount = reader1.getRowCount("Sheet1");
		System.out.println(rowCount);
		Object[] data = new Object[rowCount-1];
		for(int i=1;i<=rowCount-1;i++) {
			data[i-1] = reader1.getCellData("Sheet1", "Company Name", i+1);
		}
		//System.out.println(Arrays.toString(data));
		return data;
		
	}

}
